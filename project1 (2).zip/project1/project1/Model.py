from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class flight(db.Model)
    _tablename_="flights"
    id = db.Column(db.Integer, primary_key = True)
    origin = db.Column(db.String, nullable = False)
    destination = db.Column(db.string, nullable = False)
    duration = db.Column(db.Integer,nullable = False)

class Passenger(db.Model):
    _tablename_="passengers"
    id = db.Column(db.Integer,primary_key = True)
    flight_id = db.Column(db.Integer,db.ForeignKey("flights.id"), nullable = false)
    
    
                          
    