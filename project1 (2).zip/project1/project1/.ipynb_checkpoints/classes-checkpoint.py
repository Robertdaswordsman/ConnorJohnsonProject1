class flight:
    
    counter = 1
    
    def _init_(self,origin,destination,duration):
        self.id = flight.counter
        flight.counter +=1
        self.passengers = [] 
        self.origin = origin
        self.destination = destination
        self.duration = duration
    
    def print_info(self);
        print(f"Flight origin: {self.origin}")
        print(f"Flight destination: {self.destination}")
        print(f"Flight duration: {self.duration}")
        print()
        print("Passengers:")
        for passenge in self.passenges:
            print(f"{passenger.name}")
            
    def delay(self,amount):
        self.duration += amount
        
    def add_passenger(self,p):
        self.passengers.append(p)
        p.flight_id = self.id
        
        
class Passenger:
    def _init_(self,name):
        self.name = name